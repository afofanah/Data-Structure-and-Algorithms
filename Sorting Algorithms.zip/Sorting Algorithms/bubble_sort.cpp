#include <iostream>
using namespace std;

// Function to perform bubble sort on the array
void bubbleSort(int arr[], int n) {
    // Loop for each element of the array except the last one
    for(int i = 0; i < n-1; i++) {
        // Inner loop for comparison and swapping
        // Goes up to the part of the array that hasn't been sorted yet
        for(int j = 0; j < n-i-1; j++) {
            // If the current element is greater than the next one, swap them
            if(arr[j] > arr[j+1]) {
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

int main() {
    int arr[] = {5, 3, 8, 2, 1}; // Initial array
    int n = sizeof(arr)/sizeof(arr[0]); // Calculate the number of elements in the array
    bubbleSort(arr, n); // Call the bubbleSort function
    cout << "Sorted array: "; // Display the sorted array
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " "; // Print each element of the sorted array
    }
    return 0;
}
#include <iostream>
using namespace std;

// Function to perform selection sort on an array
void selectionSort(int arr[], int n) {
    // Loop through each element of the array except the last one
    for (int i = 0; i < n-1; i++) {
        // Assume the first unsorted element is the minimum
        int minIndex = i;
        
        // Compare this element with the rest of the unsorted portion of the array to find the true minimum
        for (int j = i+1; j < n; j++) {
            // If a smaller element is found, update minIndex with the new minimum element's index
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }

        // Swap the found minimum element with the first unsorted element
        swap(arr[i], arr[minIndex]);
    }
}

int main() {
    // Initialize array with unsorted elements
    int arr[] = {29, 10, 37, 14, 13};
    // Calculate number of elements in the array
    int n = sizeof(arr)/sizeof(arr[0]);
    
    // Call selectionSort function to sort the array
    selectionSort(arr, n);
    
    // Print the sorted array
    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    return 0;
}

 //implementing the Selection Sorting Algorithm by taking user input:
 #include <iostream>
using namespace std;

// Function to perform selection sort on an array
void selectionSort(int arr[], int n) {
    // Loop through each element of the array except the last one
    for (int i = 0; i < n-1; i++) {
        // Assume the first unsorted element is the minimum
        int minIndex = i;
        
        // Compare this element with the rest of the unsorted portion of the array to find the true minimum
        for (int j = i+1; j < n; j++) {
            // If a smaller element is found, update minIndex with the new minimum element's index
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }

        // Swap the found minimum element with the first unsorted element
        swap(arr[i], arr[minIndex]);
    }
}

int main() {
    int arr[100], n;

    // Input the number of elements
    cout << "Enter the number of elements: ";
    cin >> n;

    // Input the elements
    cout << "\nEnter " << n << " elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Sorting the array using Selection Sort
    selectionSort(arr, n);

    // Output the sorted array
    cout << "\nSorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    return 0;
}

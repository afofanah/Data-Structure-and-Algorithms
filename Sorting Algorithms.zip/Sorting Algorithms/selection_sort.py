def selectionSort(arr):
    # Traverse through all array elements
    for i in range(len(arr)):
        # Find the minimum element in the remaining unsorted array
        minIndex = i
        for j in range(i+1, len(arr)):
            if arr[j] < arr[minIndex]:
                minIndex = j
        
        # Swap the found minimum element with the first element
        arr[i], arr[minIndex] = arr[minIndex], arr[i]

# Example usage
arr = [29, 10, 37, 14, 13]
selectionSort(arr)
print("Sorted array is:", arr)

# Function to perform bubble sort on the array
def bubbleSort(arr):
    n = len(arr) # Get the number of elements in the array
    # Outer loop for traversing through each element of the array
    for i in range(n):
        # Inner loop for comparing adjacent elements
        # Goes up to the part of the array that hasn't been sorted yet
        for j in range(0, n-i-1):
            # If the current element is greater than the next one, swap them
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j] # Perform the swap

# Sample array of characters
arr = ['z', 'e', 'b', 'r', 'a']
bubbleSort(arr) # Call the bubbleSort function to sort the array
print("Sorted array is:", arr) # Print the sorted array
